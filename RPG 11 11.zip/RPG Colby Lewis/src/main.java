import static java.lang.System.*;
import java.util.*;

import java.io.*;

public class main {
	public static void clear() {
		try {
			new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
		} catch (Exception e) {
			System.out.println("Whats poppin youtube it's ya boy, " + e);
		}
	}

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		String in = "dumb";
		System.out.println("Would you like to watch the opening? (Y/N)");
		in = input.nextLine();
		if (in.equalsIgnoreCase("y")) {
			System.out.println("[???] >Oh, you're awake.");
			input.nextLine();
			System.out.println("[???] >You've been out for a while.");
			input.nextLine();
			System.out.println("[???] >It seems they put you in some sort of maximum security thing.");
			input.nextLine();
			System.out.println(">You look around and see thick looking concrete walls surrounding you except for 1 (one) barred door, it's cold in here...");
			input.nextLine();
			System.out.println(">You look down at your body and see an absurd amount of chains.");
			input.nextLine();
			System.out.println(">Like, my goodness theres so many chains.");
			input.nextLine();
			System.out.println("[???] >You must have done something really bad.");
			input.nextLine();
			System.out.println("[???] >My name's Theo by the way.");
			input.nextLine();
			System.out.println("[Theo] >What's yours?");
			input.nextLine();
		}

		Player player = new Player();
		player.choose();

		if (in.equalsIgnoreCase("y")) {
			System.out.println("[Theo] >Heh, " + player.name + ", sounds cool.");
			input.nextLine();
			System.out.println("[Theo] >Anyways wanna break out? (Y/N)");
			in = input.nextLine();
			if (in.equalsIgnoreCase("n")) {
				System.out.println("[Theo] >Hm, ok.");
				boolean waiting = true;
				while (waiting) {
				}
			} else {
				System.out.println("[Theo] >Cool.");
				input.nextLine();
				System.out.println(">You both wait for some guards to check on you...");
				input.nextLine();
				System.out.println(">Some guards come unlock the door and hand you some food");
				input.nextLine();
				if (player.maxHp > player.dmg && player.maxHp > player.spd) {
					System.out
							.println(">You walk past the guards, they arent that strong so you barely feel anything.");
					input.nextLine();
					System.out.println(">Soon the guards realize the futility and change they're target to Theo.");
					input.nextLine();
				} else if (player.dmg > player.maxHp && player.dmg > player.spd) {
					System.out.println(">You attack the guards, they weren't a match for your strength.");
					input.nextLine();
					System.out.println(
							">And while you owned them, they somehow still had the strength to instead go for Theo.");
					input.nextLine();
				} else if (player.spd > player.maxHp && player.spd > player.dmg) {
					System.out.println(">You slip past the guards, by the time they noticed, you were long gone.");
					input.nextLine();
					System.out.println(">The guards instead go for Theo.");
					input.nextLine();
				} else {
					System.out.println(">You somehow make it past the guards, but Theo isnt so lucky.");
					input.nextLine();
				}
				System.out.println("[Theo] >Dang.");
				input.nextLine();
				System.out.println(">Theo gets locked back in his cell.");
				input.nextLine();
			}
		}
		clear();

		int room = 0;

		boolean boss = false;

		for (; room < 50;) {
			if (player.hp > 0) {
				if (player.xp < 1) {
					LevelUp lvlUp = new LevelUp(player);
				} else {
					System.out.println("Press enter to go to the next room");
					in = input.nextLine();
				}
				room++;
				System.out.println("Room " + room);
				if (room % 5 == 0) {
					shop(player);
				} else if (((room - 1) % 10 == 0) && room > 1) {
					boss = true;
					System.out.println("A boss appears!");
					monsterGen monster = new monsterGen(player.lvl, boss);
					Battle battle = new Battle(player, monster);
				} else {
					boss = false;
					monsterGen monster = new monsterGen(player.lvl, boss);
					Battle battle = new Battle(player, monster);
				}
			}
		}
	}

	public static void shop(Player player) {
		Scanner input = new Scanner(System.in);
		System.out.println("Welcome to the shop!");
		boolean atShop = true;
		while (atShop) {
			System.out.println("Would you like to shop (A), talk to the shopkeep (S), or leave (D)");
			String stringIn = input.nextLine();

			if (stringIn.equalsIgnoreCase("s")) {
				System.out.print("So, " + player.name + " eh? Nice name, fits for a ");
				if (player.maxHp > player.dmg && player.maxHp > player.spd)
					System.out.print("tanky ");
				if (player.dmg > player.maxHp && player.dmg > player.spd)
					System.out.print("fierce ");
				if (player.spd > player.maxHp && player.spd > player.dmg)
					System.out.print("speedy ");
				System.out.println("guy like you.");

				boolean talking = true;
				while (talking) {
					System.out.println("Would you like to keep talking (A), check stats (S), or leave (D)");
					stringIn = input.nextLine();
					if (stringIn.equalsIgnoreCase("a")) {
						System.out.println("no");
						continue;
					}
					if (stringIn.equalsIgnoreCase("s")) {
						System.out.println("HP: " + player.maxHp);
						System.out.println("Dmg: " + player.dmg);
						System.out.println("Spd: " + player.spd);
						System.out.print("Your outermost chains seem ");
						if (player.xp > 6)
							System.out.println("strong.");
						else if (player.xp > 4)
							System.out.println("to be scratched.");
						else if (player.xp > 2)
							System.out.println("well worn.");
						else if (player.xp > 0)
							System.out.println("to be on the verge of breaking.");
						continue;
					}
					if (stringIn.equalsIgnoreCase("d")) {
						atShop = true;
						talking = false;
						continue;
					}
				}

			}
			if (stringIn.equalsIgnoreCase("a")) {
				boolean shopping = true;
				while (shopping) {
					System.out.println("You have " + player.coins + " coins.");
					System.out.println("You can buy a...");
					System.out.println("1. Health potion (20 coins)");
					if ((player.inv[1] + player.inv[2] + player.inv[3]) < 2) {
						System.out.println("2. Health charm (50 coins)");
						System.out.println("3. Damage charm (50 coins)");
						System.out.println("4. Speed charm (50 coins)");
						System.out.println("Note: You're only allowed to have 2 charms.");
					}
					System.out.println("Or press 0 to exit.");

					int in = input.nextInt();
					input.nextLine();
					if (in == 1) {
						if (player.coins > 20) {
							player.inv[0]++;
							player.coins -= 20;
						} else {
							System.out.println("You dont have enough coins for that!");
							continue;
						}
					}
					if (in == 2) {
						if (player.coins > 50) {
							player.inv[1]++;
							player.maxHp += 10;
							player.coins -= 50;
						} else {
							System.out.println("You dont have enough coins for that!");
							continue;
						}
					}
					if (in == 3) {
						if (player.coins > 50) {
							player.inv[2]++;
							player.dmg += 10;
							player.coins -= 50;
						} else {
							System.out.println("You dont have enough coins for that!");
							continue;
						}
					}
					if (in == 4) {
						if (player.coins > 50) {
							player.inv[3]++;
							player.spd += 10;
							player.coins -= 50;
						} else {
							System.out.println("You dont have enough coins for that!");
							continue;
						}
					}
					if (in == 0) {
						shopping = false;
						continue;
					}
				}
			}
			if (stringIn.equalsIgnoreCase("d")) {
				atShop = false;
				continue;
			}
		}
	}

	public static void boss() {
		System.out.println("A boss appears!");

	}
}